module.exports = {
  SECONDS_BEFORE_NEWS_UPDATE: 14400
};
