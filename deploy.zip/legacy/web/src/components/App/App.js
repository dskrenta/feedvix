import React, { Component } from 'react';
import './App.css';

class App extends Component {
  render() {
    return (
      <div>
        <p><span style={{fontFamily: 'Times New Roman'}}>The Daily</span> <span style={{fontFamily: 'Impact'}}>How<span style={{color: 'red'}}>lix</span></span></p>
        <p style={{fontFamily: 'Times New Roman'}}>David's Feed</p>
      </div>
    );
  }
}

export default App;
