module.exports = {
  TRUSTED_NEWS_SOURCES: 'abc-news,ars-technica,associated-press,bbc-news,bloomberg,business-insider,cbs-news,cnbc,cnn,engadget,financial-times,fortune,google-news,hacker-news,mashable,msnbc,national-geographic,national-review,nbc-news,new-scientist,newsweek,new-york-magazine,politico,recode,reddit-r-all,reuters,techcrunch,the-economist,the-hill,the-huffington-post,the-new-york-times,the-next-web,the-telegraph,the-verge,the-wall-street-journal,the-washington-post,the-washington-times,time,usa-today,wired'
};
